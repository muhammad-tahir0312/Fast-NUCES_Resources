
const A = [4,6,0,6,1,10,2,3,2,7,9,20];
const LIS = new Array(A.length);

for (let i = 0; i < A.length; i++) {
  LIS[i] = 1;
}


// Compute optimized LIS values in bottom up manner
for (let i = 1; i < A.length; i++) {
  for (let j = 0; j < i; j++) {
    if (A[i] > A[j] && LIS[i] < LIS[j] + 1) {
      LIS[i] = LIS[j] + 1;
    }
  }
  
}


let max = LIS[0];
for (let i = 1; i < A.length; i++) {
  if (max < LIS[i]) {
    max = LIS[i];
  }
}



