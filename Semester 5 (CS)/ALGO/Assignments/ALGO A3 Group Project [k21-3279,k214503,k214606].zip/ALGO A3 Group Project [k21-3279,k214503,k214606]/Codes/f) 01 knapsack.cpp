//part F
//0/1 knapsack


#include <iostream>
using namespace std;

int max(int a, int b) {
    return (a > b) ? a : b;
}

int knapsackFunc(int w1 , int wt[], int profit[], int n) {
    int i, weight;
    int K[n + 1][w1 + 1];

    // Build the K[][] matrix
    for (i = 0; i <= n; i++) {
        for (weight = 0; weight <= w1; weight++) {
            if (i == 0 || weight == 0)
                K[i][weight] = 0;
            else if (wt[i - 1] <= weight)
                K[i][weight] = max(profit[i - 1] + K[i - 1][weight - wt[i - 1]],
                              K[i - 1][weight]);
            else
                K[i][weight] = K[i - 1][weight];
        }
    }

    return K[n][w1];
}

int main() {
    int profit[] = {1,4,5,7,4};
    int wt[] = {1,3,4,5,2};
    int w1 = 9;
    int n = sizeof(profit) / sizeof(profit[0]);

    int maxProfit = knapsackFunc(w1, wt, profit, n);
    cout << "The maximum profit possible is: " << maxProfit << endl;

    return 0;
}

