//part d 
//levenshtein distance

#include <iostream>
#include <algorithm>
using namespace std;

int min(int a1, int a2, int a3) {
    return min(min(a1, a2), a3);
}

int levenshtein(string s1, string s2) {
    int m = s1.length();
    int n = s2.length();

    // Create a1 2D array to store the distances
    int dp[m + 1][n + 1];

    // Initialize the first row and column
    for (int i = 0; i <= m; i++) {
        dp[i][0] = i;
    }
    for (int j = 0; j <= n; j++) {
        dp[0][j] = j;
    }

    // Compute the distances
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            if (s1[i - 1] == s2[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1];
            } else {
                dp[i][j] = 1 + min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
            }
        }
    }

    // Return the Levenshtein distance
    return dp[m][n];
}

int main() {
    string s1 = "ELEPHANT";
    string s2 = "RELEVANT";

    int distance = levenshtein(s1, s2);
    cout << "change string 1: " << s1<< " into string 2: " << s2 << endl<<endl;

    cout << "The minimum levenshtein distance is: " << distance << endl<<endl<<"Means the min number of opertaions required are: "<<distance<< endl;

    return 0;
}

