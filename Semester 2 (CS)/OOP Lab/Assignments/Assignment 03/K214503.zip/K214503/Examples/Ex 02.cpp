﻿#include<iostream>
using namespace std;
class Box {
public:
double Lenght;
double Breadth;
double Height;
double Area()
{
return Lenght * Breadth;
}
double Volume()
{
return Lenght * Breadth * Height;
}
};

int main() {
Box obj;
obj.Lenght = 30;
obj.Breadth = 40;
obj.Height = 60;
cout << "Area of Box = " << obj.Area() << endl;
cout << "Volume of Box = " << obj.Area() << endl;
return 0;
}