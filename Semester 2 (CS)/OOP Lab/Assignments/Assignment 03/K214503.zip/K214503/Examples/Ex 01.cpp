﻿//Code#1:
#include<iostream>
using namespace std;
class Studnet
{
private :
string F_Name;
string L_Name;
public:
void input_value()
{
cout << "Please Enter Your First Name\n";
cin >> F_Name;
cout << "Please Enter Your Last Name \n";
cin >> L_Name;
}
void output_value()
{
cout << "Your Full Name is "<<F_Name<<" " <<L_Name;
}
};
main()
{
Studnet object;
object.input_value();
object.output_value();
//object.variable; Will produce an error because variable is private
return 0;
