﻿#include <iostream>
using namespace std;
class employee
{
public:
int E_id;
string E_name;
float E_basic;
float E_da;
float E_it;
float E_net_sel;
public:
float find_net_salary(float basic, float da, float it);
void show_emp_details();
};
float employee :: find_net_salary(float basic, float da, float it)
{
return (basic+da)-it;
}
void employee :: show_emp_details()
{
cout<<"\n\n**** Details of Employee ****";
cout<<"\nEmployee Name : "<<E_name;
cout<<"\nEmployee ID : "<<E_id;
cout<<"\nBasic Salary : "<<E_basic;
cout<<"\nEmployee DA : "<<E_da;
cout<<"\nIncome Tax : "<<E_it;
float net_salary=find_net_salary(E_basic, E_da, E_it);
cout<<"\nNet Salary : "<<net_salary;
cout<<"\n-------------------------------\n\n";
}
int main()
{
employee emp;
cout<<"\nEnter Employee ID: ";
cin>>emp.E_id;
cout<<"\nEnter Employee Name: ";
cin>>emp.E_name;
cout<<"\nEnter Employee Basic: ";
cin>>emp.E_basic;
cout<<"\nEnter Employee DA: ";
cin>>emp.E_da;
cout<<"\nEnter Employee IT: ";
cin>>emp.E_it;
emp.show_emp_details();
return 0;
}