﻿#include <iostream>
using namespace std;
class Sample_Class {
public:
void o_method();
void o_method2(int value);
void i_method()
{
cout << "This method is defined inside the class\n";
}
};
void Sample_Class::o_method()
{
cout << "This method is defined outside of the class\n";
}
void Sample_Class::o_method2(int number)
{
cout << "This method is defined outside of the class and receiving perameter,
value is: " << number << "\n";
}
int main()
{
Sample_Class obj;
obj.o_method();
obj.i_method();
obj.o_method2(101);
return 0;
}