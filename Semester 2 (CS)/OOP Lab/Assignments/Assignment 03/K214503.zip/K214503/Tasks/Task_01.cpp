﻿/*
SNO			CLASS			        OBJECT							ATTRIBUTES										            BEHAVIOURS
1.			bike	                    Honda, unique                seatingCapacity, fuelConsumption, color, rimSize	        securityAlarm(), Race(), tractionControl(), RoadGrip()		             
2.			Cafe			        employee, boss					designation, salary, experience, email			            CallMeetings(), Orders(), overTime(), hireEmployees()
3.		BussTerminal 	bus, cab						seatingCapacity, airConditioning, modelYear, driverName 	routes(), fares(), timings(), bookOnline()
4.			hotel			        tourists						rooms, parkingCapacity, conferenceRooms, touristType	    periodOfStay(), orderFood(), checkout(), checkIn()
5.			restuarant		        waiters, manager, customers 	seatingCapacity, customerName, phoneNumber, Email			serveFood(), giveReviews(), orderFood(), acceptPayments()
*/
