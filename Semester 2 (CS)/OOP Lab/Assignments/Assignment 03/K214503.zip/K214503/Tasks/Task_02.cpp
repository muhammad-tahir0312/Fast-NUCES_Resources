﻿#include<iostream>
#include<string>

using namespace std;

class bike{
	public:

	int seatingCapacity;
	float fuelConsumption;
	string color;
	float rimSize;

	public:

	void SecurityAlarm()
	{
		
		cout<<"\nCan have security alarm ";
	}

	void Race()
	{
		cout<<"\nCan modify for racing";
	}

	void tractionControl()
	{
		cout<<"\nCan use Traction Control";
	}

	void RoadGrip()
	{
		cout<<"\nHave better roadgrip";
	}
};

class Cafe{
	public:
		
	string designation;
	float salary;
	float experience;
	string email;

	public:

	void callMeetings()
	{
		cout<<"Message sent to employees for a meeting today.";
	}

	void Orders()
	{
		cout<<"\nOrders canbe taken";
	}

	void overTime()
	{
		cout<<"\n$12/hr for an overtime.";
	}

	void hireEmployees()
	{
		cout<<"\nCongratulations! You are hired.";
	}
};

class BussTerminal{
	public:

	int seatingCapacity;
	string airConditioning;
	int modelYear;
	string driverName;

	public:

	void routes()
	{
		cout<<"\nRoutes canbe set.";
	}

	void fares()
	{
		cout<<"\nFares can be set.";
	}

	void timings()
	{
		cout<<"\nTimings canbe set.";
	}

	void onlineBooking()
	{
		cout<<"\nOnline booking can be done.";
	}
};

class hotel{
	public:

	int rooms;
	int parkingCapacity;
	int conferenceRooms;
	string touristType;

	public:

	void peroidOfStay()
	{
		int stay;

		cout<<"\nDays you are staying at the hotel?: ";
		cin>>stay;

		cout<<"\nYou will stay "<<stay<<"days at Marriot.";
	}

	void orderFood()
	{
		cout<<"\nCall at our number to order food.";
	}

	void checkIn()
	{
		string time;

		cout<<"\nWhat time did you checked in?(xx:yy): ";
		cin>>time;

		cout<<"\nYou checked in at "<<time;
	}

	void checkOut()
	{
		string time;

		cout<<"\nWhat time did you checked out(xx:yy): ";
		cin>>time;

		cout<<"\nYou checked out at "<<time;
	}
};

class restuarant{
	public:

	int seatingCapacity;
	string customerName;
	double phoneNumber;
	string email;

	public:

	void orderFood()
	{
		cout<<"\ncall out the waiter to order food.";
	}

	void serveFood()
	{
		cout<<"\nThe food will be served in approx. 55 minutes.";
	}

	void giveReviews()
	{
		string review;

		cout<<"\nHow did you like our food? Tell us about it.\n\n";
		cin>>review;

		cout<<"\n"<<review;
	}

	void acceptPayments()
	{
		float cash;

		cout<<"Pay cash only. Bill is $550";
		cin >> cash;

		cout<<cash;
	}
};

int main()
{
	bike honda;
	Cafe mt;
	BussTerminal jj;
	hotel pc;
	restuarant ab;

	cout<<"HONDA";

	cout <<"\n\nSeating capacity: ";
	cin>>honda.seatingCapacity;

	cout<<"\nAvg fuel consumption: ";
	cin>>honda.fuelConsumption;

	cout<<"\nColor: ";
	cin>>honda.color;

	cout<<"\nRim size: ";
	cin>>honda.rimSize;
	
	honda.SecurityAlarm();
	honda.tractionControl();
	honda.RoadGrip();
	honda.Race();

	cout<<"\n\nCAFE";

	cout<<"\n\nDesignation: ";
	cin>>mt.designation;

	cout<<"\nSalary: ";
	cin>>mt.salary;

	cout<<"\nExperience: ";
	cin>>mt.experience;

	cout<<"\nEmail Address: ";
	cin>>mt.email;

	mt.callMeetings();
	mt.Orders();
	mt.hireEmployees();
	mt.overTime();

	cout<<"\n\nBussTerminal";

	cout<<"\n\nSeating capacity: ";
	cin>>jj.seatingCapacity;

	cout<<"\nAir conditioning?(Yes or No): ";
	cin>>jj.airConditioning;

	cout<<"\nModel: ";
	cin>>jj.modelYear;

	cout<<"\nDriver's Name: ";
	cin>>jj.driverName;

	jj.onlineBooking();
	jj.routes();
	jj.fares();
	jj.timings();

	cout<<"\n\nPC Hotel";

	cout<<"\n\nNumber of rooms: ";
	cin>>pc.rooms;

	cout<<"\nParking capacity: ";
	cin>>pc.parkingCapacity;

	cout<<"\nNumber of Conference Rooms: ";
	cin>>pc.conferenceRooms;

	cout<<"\nWhat is your Tourist type?(local or foreign): ";
	cin>>pc.touristType;

	pc.checkIn();
	pc.peroidOfStay();
	pc.orderFood();
	pc.checkOut();

	cout<<"\n\nAnwar Baloch";

	cout<<"\n\nSeating capacity: ";
	cin>>ab.seatingCapacity;

	cout<<"\nCustomer Name: ";
	cin>>ab.customerName;

	cout<<"\nPhone Number: ";
	cin>>ab.phoneNumber;

	cout<<"\nEmail: ";
	cin>>ab.email;

	ab.orderFood();
	ab.serveFood();
	ab.giveReviews();
	ab.acceptPayments();
}
