﻿#include <iostream>

using namespace std;

class PintDateTime
{
public:
	int date, month, year, hours, minutes, seconds;

public:
	void setDate()
	{
		int d;
		do
		{
			cout << "Enter date: ";
			cin >> d;

			if (d < 1 || d > 31)
				cout << "Invalid Input. Try again\n";
			
		} while (d < 1 || d > 31);
		date = d;
	}

	int getDate()
	{
		return date;
	}

	void setMonth()
	{
		int m;

		do
		{
			cout << "Enter month: ";
			cin >> m;

			if (m < 1 || m > 12)
				cout << "Invalid Input.Try again.\n";
		} while (m < 1 || m > 12);

		month = m;
	}

	int getMonth()
	{
		return month;
	}

	void setYear()
	{
		int y;
		do
		{
			cout << "Enter year: ";
			cin >> y;

			if (y < 2000 || y > 2022)
				cout << "Invalid Input.Try again.\n";
		} while (y < 2000 || y > 2022);
		year = y;
	}

	int getYear()
	{
		return year;
	}

	void setHours()
	{
		int h;
		do
		{
			cout << "Enter hour in 24-hour format: ";
			cin >> h;

			if (h < 1 || h > 23)
				cout << "Invalid Input. Try again.\n";
		} while (h < 1 || h > 23);

		hours = h;
	}

	int getHours()
	{
		return hours;
	}

	void setMinutes()
	{
		int min;
		do
		{
			cout << "Enter Minutes: ";
			cin >> min;

			if (min < 1 || min > 60)
				cout << "Invalid Input.Try again.\n";
		} while (min < 1 || min > 60);
		minutes = min;
	}

	int getMinutes()
	{
		return minutes;
	}

	void setSeconds()
	{
		int s;
		do
		{
			cout << "Enter Seconds: ";
			cin >> s;

			if (s < 1 || s > 60)
				cout << "Invalid seconds format. Try again.\n";
		} while (s < 1 || s > 60);
		seconds = s;
	}

	int getSeconds()
	{
		return seconds;
	}

	void holidayInMonth(int &monthNumber)
	{
		cout << "Welcome to holiday counter\nEnter month: ";
		cin >> monthNumber;
	}

	void tfourHourFormat()
	{
		cout << date << "-" << month << "-" << year << " " << hours << ":" << minutes << ":" << seconds;
	}
	void twelveHourFormat()
	{
		if (hours > 12)
		{
			hours = hours - 12;
			cout << date << "-" << month << "-" << year << " " << hours << ":" << minutes << ":" << seconds << " PM";
		}
		else
		{
			cout << date << "-" << month << "-" << year << " " << hours << ":" << minutes << ":" << seconds << " AM";
		}
	}
};

int main()
{
	int month;

	PintDateTime time;
	time.setDate();
	time.setMonth();
	time.setYear();
	time.setHours();
	time.setMinutes();
	time.setSeconds();

	cout << "12-hours format: \n\n";
	time.twelveHourFormat();

	cout << "\n\n24-hours format: \n\n";
	time.tfourHourFormat();
}
