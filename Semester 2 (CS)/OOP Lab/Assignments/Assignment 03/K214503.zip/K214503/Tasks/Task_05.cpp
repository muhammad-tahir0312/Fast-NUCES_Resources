﻿#include <iostream>
#include <string.h>
using namespace std;

class Student
{
private:
    int ID;
    string Name;
    char email[70];
    string coursecode[10];
    float CGPA;
    int courseNumber;

public:
    void setID();
    void setName();
    void setEmail();
    void setCGPA();
    void setCourses();
    void getID();
    void getName();
    void getEmail();
    void getGPA();
    void getCourseCode();
};

int main()
{
    Student s[10];
    for (int i = 0; i < 10; i++)
    {
        cout << "Student no. " << i + 1 << endl;
        s[i].setID();
        s[i].setName();
        s[i].setEmail();
        s[i].setCGPA();
        s[i].setCourses();
        s[i].getID();
        s[i].getName();
        s[i].getEmail();
        s[i].getGPA();
        s[i].getGPA();
        s[i].getCourseCode();
    }
}

void Student::setID()
{

    int count = 0;
    do
    {
        if (count == 0)
        {
            cout << "Student ID: ";
            cin >> ID;
        }
        if (count >= 1 && (ID > 9999 || ID < 1000))
        {
            cout << "Error! Try again. ";
            cin >> ID;
        }
        count++;
    } while (ID < 1000 || ID > 9999);

    cout << ID;
}

void Student::setCGPA()
{
    cout << "CGPA: ";
    cin >> CGPA;
}

void Student::setCourses()
{
    if (CGPA > 3)
    {
        courseNumber = 6;
    }
    else if (CGPA > 2)
    {
        courseNumber = 5;
    }
    else if (CGPA < 2)
    {
        courseNumber = 2;
    }

    cout << "Number of courses allowed: " << courseNumber << endl;
    for (int i = 0; i < courseNumber; i++)
    {
        cout << "Enter coursecode of course no. " << i + 1 << ": ";
        cin >> coursecode[i];
    }
}

void Student::setName()
{
    int count = 0;
    do
    {
        if (count == 0)
        {
            cout << "Name: ";
            cin >> Name;
        }
        if (count >= 1 && Name.length() < 3)
        {
            cout << "Name length is too short! Try again. ";
            cin >> Name;
        }
        count++;
    } while (Name.length() < 3);
}
void Student::setEmail()
{
    bool containsChar = false;
    int count = 0;
    do
    {
        if (count == 0)
        {
            cout << "Email: ";
            cin >> email;
        }

        else
        {
            cout << "Error! Try again. ";
            cin >> email;
        }
        for (int i = 0; i < strlen(email); i++)
        {
            if (email[i] == '@')
            {
                containsChar = true;
                break;
            }
        }
        count++;
    } while (strlen(email) < 6 || containsChar == false);
}

void Student::getID()
{
    cout <<"\n"<< "Student ID: " << ID;
}
void Student::getName()
{
    cout <<"\n"<< "Name: " << Name;
}

void Student::getEmail()
{
    cout <<"\n"<< "Student Email: " << email;
}

void Student::getGPA()
{
    cout <<"\n"<< "Student CGPA: " << CGPA;
}

void Student::getCourseCode()
{
    for (int i = 0; i < courseNumber; i++)
    {
        cout << "Course No. " << i + 1 << ": " << coursecode[i] << endl;
    }
}
