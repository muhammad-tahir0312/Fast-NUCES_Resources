﻿#include <iostream>
#include <string>

using namespace std;

class Robo
{
public:
    int liquidLevel = 200;

    void Drink(float &liquidDrank)
    {
        cout << "How much liquid did you drink?: ";
        cin >> liquidDrank;

        liquidLevel -= liquidDrank;

        cout << liquidLevel << " ml is left.\n\n";

        if (liquidLevel < 100)
        {
            Refill(liquidLevel);
        }
    }

    void Refill(float liquidlevel)
    {
        liquidLevel = (200 - liquidlevel) + liquidlevel;

        cout << "Your glass has been refilled.\n\n";
    }
};

int main()
{
    Robo glass;

    float liquidDrank;
    char choice;

    do
    {
        glass.Drink(liquidDrank);

        cout << "Did you drink? Y/y or N/n: ";
        cin >> choice;
    } while (choice == 'y' || choice == 'Y' );

    cout << "Program terminated!";
}
