#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>

void *thread1(){
	while(1){
		printf("Thread1\nHi\n");
	}
}

void *thread2(){
	while(1){
		printf("Thread2\nHello\n");
	}
}

int main(){
	int stat;
	pthread_t th1,th2;
	pthread_create(&th1,NULL,thread1,NULL);
	pthread_create(&th2,NULL,thread2,NULL);
	pthread_join(th1,NULL);
	pthread_join(th2,NULL);
}
