#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    pid_t pid = getpid(); // Get the process ID of the current process
    int signal_number = SIGTERM; // Signal number to send

    printf("Sending signal %d to process %d\n", signal_number, pid);

    // Send the signal to the current process
    if (kill(pid, signal_number) == -1) {
        perror("kill");
        exit(EXIT_FAILURE);
    }

    return 0;
}

