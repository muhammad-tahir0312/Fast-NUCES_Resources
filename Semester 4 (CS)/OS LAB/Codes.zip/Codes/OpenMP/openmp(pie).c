#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <signal.h>
#include <omp.h>

#define N 1000000

int stop = 0;

void handle_signal(int signal) {
    if (signal == SIGINT) {
        stop = 1;
    }
}

int main(int argc, char **argv) {

    signal(SIGINT, handle_signal);

    long double pi = 0.0;
    int i, j;

    omp_set_num_threads(15);
    #pragma omp parallel for private(j) reduction(+:pi)
    for (i = 0; i < N; i++) {
        long double term = 0.0;
        for (j = 0; j < 25 && i * 25 + j < N; j++) {
            int k = i * 25 + j;
            term += powl(16.0, -k) * (4.0 / (8.0 * k + 1.0) - 2.0 / (8.0 * k + 4.0) - 1.0 / (8.0 * k + 5.0) - 1.0 / (8.0 * k + 6.0));
        }
        pi += term;
    }

    if (stop) {
        printf("Calculation interrupted at digit %d.\n", i * 25);
    } else {
        pi = pi * 1e14;
        pi = roundl(pi);
        pi = pi / 1e14;
        printf("The millionth digit of pi is %Lf.\n", pi);
    }

    return 0;
}
