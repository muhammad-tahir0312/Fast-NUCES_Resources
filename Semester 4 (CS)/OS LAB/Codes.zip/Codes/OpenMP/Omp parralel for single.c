#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

#define N 10000

void bubble_sort(int arr[], int size)
{
	int i=0; 
	int j=0;
	
    for(i = 0; i < size - 1; i++)
	{
        for(j = 0; j < size - i - 1; j++)
		{
            if (arr[j] > arr[j+1])
			{
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

int main() 
{
    int arr[N];
    
    srand(time(NULL));
    
    int i=0;
    
    for(i = 0; i < N; i++)
	{
        arr[i] = rand() % 100 + 1;
    }

    int sorted = 0;
    #pragma omp parallel
    {
        while(!sorted)
		{
			int j=0;
			
            #pragma omp for
            for (j = 0; j < N; j = j + 2)
			{
                if (j < N - 1 && arr[j] > arr[j+1])
				{
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            }

			int k=0;
			
            #pragma omp for
            for(k = 1; k < N; k = k + 2)
			{
                if (k < N - 1 && arr[k] > arr[k+1])
				{
                    int temp = arr[k];
                    arr[k] = arr[k+1];
                    arr[k+1] = temp;
                }
            }

            #pragma omp single
            {
                int local_sorted = 1;
                
                int m=0;
                
                for(m = 0; m < N - 1; m++)
				{
                    if (arr[m] > arr[m+1])
					{
                        local_sorted = 0;
                        break;
                    }
                }
                sorted = local_sorted;
            }
        }
    }
	
	int l=0;
	
    printf("Sorted array:\n");
    for(l = 0; l < N; l++)
	{
        printf("%d ", arr[l]);
    }
    
    printf("\n");

    return 0;
}

