#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

//export OMP_NUM_THREADS=10

int main() {
	
	int i;
	int A[10000];
	int max;
	int index;
	
	srand(time(NULL));
	
	for(i=0;i<10000;i++)
	{
		A[i]=rand() % 100 +1;
		printf("%d\n",A[i]);
	}
	
	max=A[0];
	omp_set_num_threads(10);
	
	#pragma omp parallel for 
		for(i=0;i<10000;i++)
		{
			#pragma omp critical
			{
				if(max<A[i])
				{
					max=A[i];
					index = i;
				}
			}
		}

	
	printf("\nMAX Value = %d\nINDEX = %d\n",max,index);
	return 0;
}
