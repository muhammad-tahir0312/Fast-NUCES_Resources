#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

#define N 100

int main()
{
    int matrix1[N][N], matrix2[N][N], summatrix[N][N];
    
    srand(time(NULL));
    int a=0;
    int b=0;
    
    for(a = 0; a < N; a++)
	{
        for (b = 0; b < N; b++)
		{
            matrix1[a][b] = rand() % 100 + 1;
            matrix2[a][b] = rand() % 100 + 1;
        }
    }

    #pragma omp parallel for
    int i=0;
    int x=0;
    
    for(i = 0; i < N; i++)
	{
        for (x= 0; x < N; x++)
		{
            summatrix[i][x] = matrix1[i][x] + matrix2[i][x];
        }
    }

    printf("Matrix 1:\n\n\n");
    
    int j=0;
    int k=0;
    
    for(j= 0; j < N; j++)
	{
        for (k = 0; k < N; k++)
		{
            printf("%d ", matrix1[j][k]);
        }
        printf("\n");
    }

    printf("\nMatrix 2:\n\n\n");
    
    int l=0;
    int m=0;
    
    for(l = 0; l < N; l++)
	{
        for(m = 0; m < N; m++)
		{
            printf("%d ", matrix2[i][j]);
        }
        
        printf("\n");
    }

    printf("\nSum:\n\n\n");
    
    int p=0;
    int q=0;
    
    for(p = 0; p < N; p++)
	{
        for(q = 0; q < N; q++)
		{
            printf("%d ", summatrix[p][q]);
        }
        
        printf("\n");
    }

    return 0;
}
