#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

#define N 10000

int main()
{
    int arr[N];
    
    srand(time(NULL));
    
    int i=0;
    
    for(i = 0; i < N; i++)
	{
        arr[i] = rand() % 100 + 1;
    }

    int max=0;
    int indexmax=0;
    
    int j=0;
    
    #pragma omp parallel for
    for(j = 0; j < N; j++)
	{
        #pragma omp critical
        {
            if (arr[i] > max)
			{
                max = arr[i];
                indexmax = i;
            }
        }
    }

    printf("Maximum value = %d\n", max);
    printf("Maximum value's index in array = %d", indexmax);

    return 0;
}
