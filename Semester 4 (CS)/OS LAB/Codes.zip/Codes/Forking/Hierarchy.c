#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
	int child1, child2, child3;
	
	child1 = fork();
	if (child1 == 0)
	{
		sleep(2);
		printf("Child_01: %d Parent: %d\n",getpid(),getppid());
	}

	else
	{
		child2 = fork();
		if (child2 == 0)
		{
			sleep(1);
			printf("Child_02: %d Parent: %d\n",getpid(),getppid());
		}
		
		else
		{
			child3 = fork();
			if (child3 == 0)
			{
				printf("Child_03: %d Parent: %d\n",getpid(),getppid());
			}

			else
			{
				wait(NULL);
				wait(NULL);
				wait(NULL);
				printf("Parent: %d\n",getpid());
			}
		}
	}

	return 0;
}
