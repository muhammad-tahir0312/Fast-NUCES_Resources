#include<stdio.h>
#include<pthread.h>

volatile int counter=0;
pthread_mutex_t mymutex;
int argc; char *argv[];
void *mutex_testing(void *param){
	int i;
	for(i=0; i<4;i++){
		pthread_mutex_lock(&mymutex);
		counter++;
		printf("\nThread %d counter %d",(int)param, counter);
		pthread_mutex_unlock(&mymutex);
	}
}

int main(){
	int one=1,two=2,three=3;
	pthread_t th1,th2,th3;
	pthread_mutex_init(&mymutex,0);
	pthread_create(&th1,0,mutex_testing,(void*)one);
	pthread_create(&th2,0,mutex_testing,(void*)two);
	pthread_create(&th2,0,mutex_testing,(void*)three);
	pthread_join(th1,0);
	pthread_join(th2,0);
	pthread_join(th3,0);
	pthread_mutex_destroy(&mymutex);
	return 0;
}
