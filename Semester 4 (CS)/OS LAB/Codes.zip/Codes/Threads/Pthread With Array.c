#include<stdio.h>
#include<pthread.h>

void* myprint(void *x)
{
    int *k = (int *) x;
    int c2=k[2];
    printf("\n Thread created.. value of k [%d]\n", c2);
    //k =11;
    pthread_exit((void *)c2);
}

int main()
{
    pthread_t th1;
    int x[5] ={1,2,3,4,5};
    int *y;
    pthread_create(&th1, NULL, myprint, (void*)x);
    pthread_join(th1, &y);
    printf("\n Exit value is [%d]\n", y);
}  
