#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t weightMutex;
sem_t securityMutex;
sem_t boardingMutex;

void *boardingLounge(void *id)
{
	int passenger = *((int*)id);
	
	sem_wait(&weightMutex);
	printf("Passenger %d weighing luggage.\n", passenger);
	sleep(4);
	sem_wait(&securityMutex);
	sem_post(&weightMutex);
	printf("Passenger %d getting security check.\n", passenger);
	sleep(7);
	sem_wait(&boardingMutex);
	sem_post(&securityMutex);
	printf("Passenger %d getting boarding pass.\n", passenger);
	sleep(3);
	sem_post(&boardingMutex);
}

int main()
{
	sem_init(&weightMutex, 0, 1);
	sem_init(&securityMutex, 0, 1);
	sem_init(&boardingMutex, 0, 1);
	
	pthread_t tid[10];
	int i = 0;
	int passID[10];
	
	for(i = 0; i < 10; i++)
		passID[i] = i + 1;

	for(i = 0; i < 10; i++)
		pthread_create(&tid[i], NULL, boardingLounge, (void *)&passID[i]);
	
	for(i = 0; i < 10; i++)
		pthread_join(tid[i], NULL);
	
	return 0;
}
