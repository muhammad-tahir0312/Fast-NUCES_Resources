#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t semLock;
int tickets = 100, ticketNO = 0;

void *ticketingSystem(void *arg)
{
	int seller = *((int*)arg);
	sem_wait(&semLock);	
	
	if(tickets > 0)
	{
		ticketNO++;
		tickets--;
		printf("Seller %d issued Ticket # %d.\n", seller, ticketNO);
	}
	
	sem_post(&semLock);	
}

int main()
{
	pthread_t tid[5];
	int i;
	int sellerID[5];
	sem_init(&semLock, 0, 1);
	
	for(i = 0; i < 5; i++)
		sellerID[i] = i + 1;
		
	while(tickets > 0)
		for(i = 0; i < 5; i++)
			pthread_create(&tid[i], NULL, ticketingSystem, (void*)&sellerID[i]);
	
	for(i = 0; i < 5; i++)
		pthread_join(tid[i],NULL);
	
	return 0;	
}
