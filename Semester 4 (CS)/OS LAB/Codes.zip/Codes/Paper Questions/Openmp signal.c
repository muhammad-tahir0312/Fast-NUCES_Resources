#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>
#include <signal.h>
#include <unistd.h>
#define SIZE 100000

int arr[SIZE];

void signal_quit(int d)
{
	int i;
	printf("Quiting sort!\n");
	
	exit(0);
}

void signal_pause(int d)
{
	printf("program Paused!\n");
	sleep(4);
	printf("program resumed!\n");
}



int main() {

	
    signal(SIGINT,signal_quit);
    signal(SIGTSTP,signal_pause);	
    srand(time(NULL));
    for (int i = 0; i < SIZE; i++) {
        arr[i] = rand() % 100 + 1;
    }

    omp_set_num_threads(1);
    
    #pragma omp parallel
    {
        #pragma omp for
        
        for (int i = 0; i < SIZE; i++) {
            for (int j = i+1; j < SIZE; j++) {
                if (arr[i] > arr[j]) {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
    }

    printf("Sorted array:\n");
    for (int i = 0; i < SIZE; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}




