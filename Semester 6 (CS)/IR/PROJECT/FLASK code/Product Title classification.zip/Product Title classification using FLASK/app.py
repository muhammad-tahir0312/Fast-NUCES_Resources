import pickle
import copy
import pandas as pd
import re
import time
from collections import defaultdict
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from flask import Flask, render_template, request
from nltk.stem.porter import PorterStemmer
from nltk.corpus import stopwords

app = Flask(__name__)

# Home route
@app.route("/", methods=['GET', 'POST'])
def home():
    title, description, category1, category2, category3, exec_time = None, None, None, None, None, None

    if request.method == "POST":
        title = request.form['title']

        # Start time for measuring execution time
        start_time = time.time()
        
        # Preprocess the input text
        processed_query = preprocess_text(title)
        
        # Predict categories for the input text
        model1_pred, model2_pred, model3_pred = predict_category(processed_query)
        
        # Calculate execution time
        exec_time = time.time() - start_time

        # Get unique labels for decoding
        unique_labels1, unique_labels2, unique_labels3 = get_unique_labels()
        
        # Decode the predicted labels if predictions are not None
        if model1_pred is not None:
            category1 = decode_label(int(model1_pred[0]), unique_labels1)
        if model2_pred is not None:
            category2 = decode_label(int(model2_pred[0]), unique_labels2)
        if model3_pred is not None:
            category3 = decode_label(int(model3_pred[0]), unique_labels3)
        
    return render_template('HomePage.html', title=title,
                           Category_1=category1, Category_2=category2, Category_3=category3, Execution_Time=exec_time)

# Analysis route
@app.route("/analysis", methods=['GET'])
def analysis():
    return render_template("Analysis.html")

# Load SVM models
def load_models():
    model1 = pickle.load(open('Models/model_1.pickle', 'rb'))
    model2 = pickle.load(open('Models/model_2.pickle', 'rb'))
    model3 = pickle.load(open('Models/model_3.pickle', 'rb'))
    return model1, model2, model3

# Preprocess text
def preprocess_text(content):
    # Initialize Porter Stemmer
    stemmer = PorterStemmer()
    
    # Regular expression to clean HTML tags
    cleanr = re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});')

    # Remove non-alphabetic characters, HTML tags, and convert to lowercase
    stemmed_content = re.sub('[^a-zA-Z]',' ',str(content))
    stemmed_content = re.sub(cleanr, '',stemmed_content)
    stemmed_content = stemmed_content.lower()
    
    # Tokenize and apply stemming
    stemmed_content = stemmed_content.split()
    stemmed_content = [stemmer.stem(word) for word in stemmed_content if not word in stopwords.words('english')]
    stemmed_content = ' '.join(stemmed_content)

    return stemmed_content

# Predict category
def predict_category(query):
    # Load vectorizer
    vectorizer = pickle.load(open('Models/vectorizer.pickle', 'rb'))
    
    # Create corpus vocabulary
    corpus_vocab = defaultdict(None, copy.deepcopy(vectorizer.vocabulary_))
    corpus_vocab.default_factory = corpus_vocab.__len__

    # Load SVM models
    model1, model2, model3 = load_models()

    # Transform input query using the vectorizer
    transformer_query = TfidfVectorizer()
    try:
        transformer_query.fit_transform([query])
    except ValueError:
        print("The document only contains stop words. Skipping...")
        return None, None, None
    
    # Update corpus vocabulary with query terms
    for word in transformer_query.vocabulary_.keys():
        if word in vectorizer.vocabulary_:
            corpus_vocab[word]

    # Transform input query using the updated corpus vocabulary
    transformer_query_sec = TfidfVectorizer(vocabulary=corpus_vocab)
    query_tfidf_matrix = transformer_query_sec.fit_transform([query])

    # Predict categories using SVM models
    return model1.predict(query_tfidf_matrix), model2.predict(query_tfidf_matrix), model3.predict(query_tfidf_matrix)

# Decode label
def decode_label(number, unique_labels):
    encoder = LabelEncoder()
    encoder.fit(unique_labels)
    return str(encoder.inverse_transform([number])[0])

# Get unique labels
def get_unique_labels():
    df = pd.read_csv("labels.csv")
    unique_label1 = df['category1'].dropna().unique()
    unique_label2 = df['category2'].dropna().unique()
    unique_label3 = df['category3'].dropna().unique()
    return unique_label1, unique_label2, unique_label3

if __name__ == "__main__":
    app.run(debug=True)