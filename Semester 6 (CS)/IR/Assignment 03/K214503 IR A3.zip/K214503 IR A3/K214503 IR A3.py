"""
This script provides a GUI for a text clustering application.
It allows users to search for research papers, retrieve relevant documents, and display them in a tree view.

The `TextClusteringApp` class is the main entry point for the text clustering application. 
It provides a graphical user interface (GUI) that allows users to search for research papers and view the retrieved documents.

Key Features:
- Initializes the user interface with various layout components, including a search field, search button, and tree view for displaying retrieved documents.
- Implements the `search` method to process the user's query, retrieve relevant documents, and display them in the tree view.

The `TextClusteringApp` class relies on other classes and modules, including `VectorSpaceModel` and `load_research_papers`, for handling text processing and document retrieval tasks.
"""


# Import necessary libraries
import os
import re
import string
import json
import sys
import numpy as np
from collections import defaultdict, Counter
from typing import List, Dict
from pathlib import Path
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTreeView, QToolTip
from PyQt5.QtGui import QStandardItemModel, QStandardItem, QIcon, QFont
from PyQt5.QtCore import QPoint
from PyQt5.QtWidgets import (
    QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTreeView, QWidget, QGridLayout
)
from PyQt5.QtCore import Qt
from nltk.stem import PorterStemmer
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn import metrics
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score, silhouette_score
from sklearn.metrics.cluster import adjusted_rand_score

class_labels = {
    "Explainable Artificial Intelligence": [1,2,3,7],
    "Heart Failure": [8,9,11],
    "Time Series Forecasting": [12,13,14,15,16],
    "Transformer Model": [17,18,21],
    "Feature Selection": [22,23,24,25,26]
}

y = []
for class_name, documents in class_labels.items():
    for _ in documents:
        y.append(class_name)

# Initialize KNN classifier
knn = KNeighborsClassifier()

n_clusters = int(input("Enter Value of K: "))
# Initialize KMeans clustering
kmeans = KMeans(n_clusters=5)

# Define file paths
STOPWORDS_FILE = Path('Stopword-List.txt')
DICTIONARY_FILE = Path('Dictionary.txt')
TFIDF_MATRIX_FILE = Path('tfidf_matrix.json')
VOCABULARY_FILE = Path('vocabulary.json')
IDF_FILE = Path('idf.json')
ICON_PATH = Path('path_to_your_icon.png')

def load_file(file_path):
    """
        loads a file from the specified file and return the list as output.
    """
    try:
        with file_path.open('r', encoding='latin-1') as file:
            return [word.strip() for word in file.readlines()]
    except FileNotFoundError:
        print(f"File {file_path} not found.")
        return []

# Define constants
RESEARCH_PAPERS_DIR = 'ResearchPapers'
FILE_COUNT = 30
ALPHA = 0.05

# Load stopwords
STOPWORDS = load_file(STOPWORDS_FILE)

# Sample test data for evaluation
sample_test_data = {
    "Explainable Artificial Intelligence": "Explainable Artificial Intelligence (XAI) refers to AI algorithms and systems that can provide explanations for their decisions and outputs. This field aims to make AI more transparent and understandable to humans. XAI techniques include generating human-readable explanations, highlighting important features in the data, providing causal reasoning behind the AI's decisions, and integrating interpretability into various types of AI models.",
    "Heart Failure": "Heart failure is a chronic condition where the heart is unable to pump blood efficiently to meet the body's needs. It can be caused by various factors such as coronary artery disease, high blood pressure, infections, and genetic predisposition. Symptoms of heart failure include shortness of breath, fatigue, weakness, and swelling in the legs and abdomen. Treatment options include lifestyle changes, medication, heart-assist devices, and in severe cases, heart transplantation.",
    "Time Series Forecasting": "Time series forecasting is a technique used to predict future values based on past observations. It is commonly used in finance, weather forecasting, sales forecasting, and demand forecasting for various industries. Time series data consists of observations recorded at regular time intervals, such as daily stock prices, hourly temperature readings, and monthly sales figures. Techniques used for time series forecasting include ARIMA models, exponential smoothing, machine learning algorithms, and advanced deep learning architectures like LSTM and GRU.",
    "Transformer Model": "The transformer model is a type of deep learning model that has been widely adopted for natural language processing tasks. It is known for its attention mechanism, which allows it to focus on different parts of the input sequence, handle long-range dependencies, and capture contextual information effectively. The transformer model has enabled significant advancements in tasks such as machine translation, text summarization, document classification, and named entity recognition. Variants of the transformer model include BERT, GPT, T5, and RoBERTa, each designed for specific NLP applications and domains.",
    "Feature Selection": "Feature selection is the process of selecting a subset of relevant features from a larger set of features to improve the performance of machine learning models. It helps in reducing overfitting, improving model interpretability, and enhancing model training efficiency. Feature selection techniques include filter methods, wrapper methods, embedded methods, and ensemble methods. These techniques evaluate the relevance and importance of features based on various criteria such as correlation, mutual information, statistical significance, and predictive power."
}

# GUI class for the application
class GUI(QWidget):
    def __init__(self, vector_space_model, research_papers):
        """
            Initialize the GUI.
        """
        super().__init__()
        self.vector_space_model = vector_space_model
        self.research_papers = research_papers
        self.init_ui()

    # def init_ui(self):
    def init_ui(self):
        """
        Initialize the user interface.
        """
        # Set the size of the GUI
        self.setFixedSize(900, 900)
        
        # Layout setup
        layout = QVBoxLayout()
        self.setWindowTitle("IR Assignment 03")
        self.setWindowIcon(QIcon(str(ICON_PATH)))

        # Search layout setup
        search_layout = QHBoxLayout()
        search_label = QLabel("Enter Query:")
        search_label.setStyleSheet("font-size: 16pt; color: #2E86C1; font-weight: bold;")
        self.search_field = QLineEdit()
        self.search_field.setStyleSheet("font-size: 16pt; background-color: #E5E7E9; color: #333;") 
        search_layout.addWidget(self.search_field)

        self.search_button = QPushButton("Search")
        self.search_button.setStyleSheet(
            "font-size: 16pt; padding: 8px 15px; background-color: #007bff; color: white;"
            "border-radius: 5px; border: 2px solid #007bff;"
        )
        self.search_button.clicked.connect(self.search)
        search_layout.addWidget(self.search_button)

        layout.addLayout(search_layout)

        # Tree views setup in 2 columns
        tree_views_layout = QHBoxLayout()

        # First Column
        first_column_layout = QVBoxLayout()

        self.tree_view = QTreeView()
        self.tree_view.setStyleSheet("font-size: 14pt; background-color: #F9F9F9; color: #333;")
        self.tree_view.setRootIsDecorated(False)
        self.tree_view.setAlternatingRowColors(True)
        self.tree_view.setHeaderHidden(True)
        self.tree_view.setModel(None)
        self.add_tree_view(first_column_layout, "Retrieved Docs", self.tree_view)

        self.classification_tree_view = QTreeView()
        self.classification_tree_view.setStyleSheet("font-size: 14pt; background-color: #F9F9F9; color: #333;")
        self.classification_tree_view.setRootIsDecorated(False)
        self.classification_tree_view.setAlternatingRowColors(True)
        self.classification_tree_view.setHeaderHidden(True)
        self.classification_tree_view.setModel(None)
        self.add_tree_view(first_column_layout, "Text Classification", self.classification_tree_view)
        
        name_label = QLabel("Developed by: Muhammad Tahir K214503")
        name_label.setStyleSheet("font-size: 12pt; color: #555;")
        layout.addWidget(name_label)
        first_column_layout.addWidget(name_label)

        # Second Column
        second_column_layout = QVBoxLayout()

        self.cluster_tree_view = QTreeView()
        self.cluster_tree_view.setStyleSheet("font-size: 14pt; background-color: #F9F9F9; color: #333;")
        self.cluster_tree_view.setRootIsDecorated(False)
        self.cluster_tree_view.setAlternatingRowColors(True)
        self.cluster_tree_view.setHeaderHidden(True)
        self.cluster_tree_view.setModel(None)
        self.add_tree_view(second_column_layout, "Text Clustering", self.cluster_tree_view)

        self.metrics_tree_view = QTreeView()
        self.metrics_tree_view.setStyleSheet("font-size: 14pt; background-color: #F9F9F9; color: #333;")
        self.metrics_tree_view.setRootIsDecorated(False)
        self.metrics_tree_view.setAlternatingRowColors(True)
        self.metrics_tree_view.setHeaderHidden(True)
        self.metrics_tree_view.setModel(None)
        self.add_tree_view(second_column_layout, "Text Classification Evaluation Metrics", self.metrics_tree_view)

        self.clustering_metrics_tree_view = QTreeView()
        self.clustering_metrics_tree_view.setStyleSheet("font-size: 14pt; background-color: #F9F9F9; color: #333;")
        self.clustering_metrics_tree_view.setRootIsDecorated(False)
        self.clustering_metrics_tree_view.setAlternatingRowColors(True)
        self.clustering_metrics_tree_view.setHeaderHidden(True)
        self.clustering_metrics_tree_view.setModel(None)
        self.add_tree_view(second_column_layout, "Text Clustering Evaluation Metrics", self.clustering_metrics_tree_view)

        tree_views_layout.addLayout(first_column_layout)
        tree_views_layout.addLayout(second_column_layout)

        layout.addLayout(tree_views_layout)

        self.setLayout(layout)


    # Other methods like update_metrics, classify, purity_score, etc.
    def add_tree_view(self, layout, label_text, tree_view):
        """
        Add tree view to the layout with a label.
        """
        label = QLabel(label_text)
        label.setStyleSheet("font-size: 14pt; color: #555; font-weight: bold; margin-top: 10px;")
        layout.addWidget(label)
        layout.addWidget(tree_view)
    
    # Other methods like update_metrics, classify, purity_score, etc.
    def update_metrics(self, precision, recall, f1, accuracy):
        """
        Update the metrics in the GUI.
        """
        model = QStandardItemModel()
        model.setHorizontalHeaderLabels(["Metrics", "Values"])
        model.appendRow([QStandardItem("Precision"), QStandardItem(str(precision))])
        model.appendRow([QStandardItem("Recall"), QStandardItem(str(recall))])
        model.appendRow([QStandardItem("F1 Score"), QStandardItem(str(f1))])
        model.appendRow([QStandardItem("Accuracy"), QStandardItem(str(accuracy))])
        self.metrics_tree_view.setModel(model)

    def classify(self):
        """
        Classify the query using the KNN model.
        """
        query = self.search_field.text()
        if query!= '':
            query_vector = self.vector_space_model.vectorizer.transform([query])
            prediction = knn.predict(query_vector)
            model = QStandardItemModel()
            model.setHorizontalHeaderLabels(["Classification"])
            model.appendRow([QStandardItem(prediction[0])])
            self.classification_tree_view.setModel(model)

    def purity_score(self, y_true, y_pred):
        """
        Compute the purity score.
        """
        # compute contingency matrix (also called confusion matrix)
        contingency_matrix = metrics.cluster.contingency_matrix(y_true, y_pred)
        # return purity
        return np.sum(np.amax(contingency_matrix, axis=0)) / np.sum(contingency_matrix) 

    def silhouette_score(self, X, labels):
        """
        Compute the silhouette score.
        """
        return silhouette_score(X, labels, metric='euclidean')

    def rand_index_score(self, y_true, y_pred):
        """
        Compute the adjusted rand index score.
        """
        return adjusted_rand_score(y_true, y_pred)

    def update_clustering_metrics(self, purity, silhouette, rand_index):
        """
        Update the clustering metrics in the GUI.
        """
        model = QStandardItemModel()
        model.setHorizontalHeaderLabels(["Metrics", "Values"])
        model.appendRow([QStandardItem("Purity"), QStandardItem(str(purity))])
        model.appendRow([QStandardItem("Silhouette Score"), QStandardItem(str(silhouette))])
        model.appendRow([QStandardItem("Rand Index"), QStandardItem(str(rand_index))])
        self.clustering_metrics_tree_view.setModel(model)

    def calculate_clustering_metrics(self):
        """
        Calculate and update clustering metrics.
        """
        # Create a list of true labels in the same order as the documents in your dataset
        labels_true = []
        for class_name, documents in class_labels.items():
            for document in documents:
                labels_true.append(class_name)

        labels_pred = kmeans.labels_

        purity = self.purity_score(labels_true, labels_pred)
        silhouette = self.silhouette_score(self.vector_space_model.tfidf_matrix, labels_pred)
        rand_index = self.rand_index_score(labels_true, labels_pred)

        self.update_clustering_metrics(purity, silhouette, rand_index)

    def cluster(self):
        """
        Cluster the query using the KMeans model.
        """
        query = self.search_field.text()
        if query!= '':
            query_vector = self.vector_space_model.vectorizer.transform([query])
            cluster = kmeans.predict(query_vector)
            model = QStandardItemModel()
            model.setHorizontalHeaderLabels(["Cluster"])
            model.appendRow([QStandardItem(str(cluster[0]))])
            self.cluster_tree_view.setModel(model)

    def search(self):
        """
             Search documents, calculate evaluation metrics, and update GUI.
        """
        # Disable the search button to prevent multiple simultaneous searches
        self.search_button.setEnabled(False)
    
        # Get the query from the search field
        query = self.search_field.text()
    
        # Assign the kmeans object to the instance variable
        self.kmeans = kmeans
    
        # If the query is not empty, perform the search
        if query != '':
            # Classify and cluster the documents
            self.classify()
            self.cluster()
    
            # Process the queries and get the results
            results = self.vector_space_model.process_queries([query])
    
            # Filter out the relevant documents based on the similarity score
            relevant_docs = [(list(self.research_papers.keys())[idx], sim) for idx, sim in enumerate(results[query]) if sim >= ALPHA]
    
            # Sort the relevant documents in descending order of similarity
            relevant_docs.sort(key=lambda x: x[1], reverse=True)
    
            # If there are any relevant documents, update the tree view with the documents
            if relevant_docs:
                model = QStandardItemModel()
                model.setHorizontalHeaderLabels(["Documents"])
                for doc in relevant_docs:
                    item1 = QStandardItem(doc[0])
                    model.appendRow([item1])
                self.tree_view.setModel(model)
            else:
                # If there are no relevant documents, show a tooltip with the message
                self.tree_view.setModel(None)
                QToolTip.showText(self.search_field.mapToGlobal(QPoint(0, 0)), "No results found for the given query.")
        else:
            # If the query is empty, show a tooltip with the message
            self.tree_view.setModel(None)
            QToolTip.showText(self.search_field.mapToGlobal(QPoint(0, 0)), "There is nothing to be searched.")
    
        # Enable the search button after the search is complete
        self.search_button.setEnabled(True)
    
        # Calculate evaluation metrics
        all_test_predictions = []
        for query in sample_test_data.values():
            query_vector = self.vector_space_model.vectorizer.transform([query])
            prediction = knn.predict(query_vector)
            all_test_predictions.append(prediction[0])
    
        # Calculate precision, recall, f1 score, and accuracy
        precision = precision_score(sample_test_labels, all_test_predictions, average='macro', zero_division=0)
        recall = recall_score(sample_test_labels, all_test_predictions, average='macro')
        f1 = f1_score(sample_test_labels, all_test_predictions, average='macro')
        accuracy = accuracy_score(sample_test_labels, all_test_predictions)
    
        # Update the metrics on the GUI
        self.update_metrics(precision, recall, f1, accuracy)
    
        # Calculate and update clustering metrics
        self.calculate_clustering_metrics()
    
    def run(self):
        """
             Run the GUI application
        """
        # Show the GUI
        self.show()
    
        # Exit the application when the GUI is closed
        sys.exit(app.exec_())

class TextPreprocessor:
    """
        Handles text preprocessing tasks including punctuation and number removal, tokenization, stemming, and dictionary management.
    """
    def __init__(self, corpus: List[str]):
        """
            Initialize the TextPreprocessor with a corpus of text.
        """
        self.corpus = corpus
        self.stemmer = PorterStemmer()
        self.token_pattern = re.compile(r"\w+(?:['-,]\w+)?|[^_\w\s]")
        self.dictionary = {}
        self.dictionary = self.load_or_create_dictionary()

    def remove_punctuation_and_numbers(self, text: str) -> str:
        """
            Remove punctuation and numbers from a given text.
        """
        return text.translate(str.maketrans('', '', string.punctuation + string.digits))

    def tokenize_and_stem(self, text: str) -> List[str]:
        """
            Tokenize and stem a given text.
        """
        text = self.remove_punctuation_and_numbers(text.lower())
        tokens = self.token_pattern.findall(text)
        return [self.stemmer.stem(token) for token in tokens if token.isalpha() and token not in STOPWORDS]

    def load_or_create_dictionary(self) -> Dict[str, int]:
        """
            Load or create a dictionary of words from the corpus.
        """
        if DICTIONARY_FILE.exists():
            with DICTIONARY_FILE.open('r') as file:
                self.dictionary = json.load(file)
        else:
            for doc in self.corpus:
                tokens = self.tokenize_and_stem(doc)
                for token in tokens:
                    self.dictionary[token] = self.dictionary.get(token, 0) + 1
            with DICTIONARY_FILE.open('w') as file:
                json.dump(self.dictionary, file)
        return self.dictionary

class ResearchPapersLoader:
    """
        Handles loading research papers from a specified directory.
    """
    def __init__(self, directory, file_count):
        """
            Initialize the ResearchPapersLoader with the directory and file count.
        """
        self.directory = directory
        self.file_count = file_count

    def generate_file_paths(self):
        """
            Generate the file paths for the research papers.
        """
        # Generate file paths for the given range and check if the file exists
        return [f'{self.directory}/{i}.txt' for i in range(1, self.file_count + 1) if os.path.exists(f'{self.directory}/{i}.txt')]

    def load_research_papers(self):
        """
            Load the research papers from the file paths.
        """
        # Generate the file paths
        file_paths = self.generate_file_paths()
        research_papers = {}
        # For each file path, open the file and read the content
        for path in file_paths:
            with open(path, 'r', encoding='latin-1') as file:
                content = file.read()
                # Add the content to the dictionary with the file name as the key
                research_papers[os.path.basename(path)] = content
        return research_papers

class CustomTfidfVectorizer:
    """
        Custom TF-IDF vectorizer implementation for tokenizing and transforming text.
    """
    def __init__(self, tokenizer):
        """
            Initialize the CustomTfidfVectorizer with a tokenizer.
        """
        self.tokenizer = tokenizer
        self.vocabulary_ = {}  
        self.idf_ = []  

    def fit(self, corpus):
        """
        Fit the model to a corpus. This involves building the vocabulary and calculating the IDF values.
        """
        total_documents = len(corpus)
        document_count = defaultdict(int)
        # For each document in the corpus
        for doc in corpus:
            # Tokenize the document and get the unique words
            words = set(self.tokenizer(doc))
            # For each unique word, increment its document count
            for word in words:
                document_count[word] += 1
        # For each word and its document count
        for word, count in document_count.items():
            # Add the word to the vocabulary and calculate its IDF
            self.vocabulary_[word] = len(self.vocabulary_)
            idf = 1 + np.log(total_documents / (1 + count))
            self.idf_.append(idf)
        return self

    def transform(self, corpus):
        """
            Transform a corpus into TF-IDF vectors.
        """
        matrix = []
       
        for doc in corpus:
            # Tokenize the document and get the word counts
            words = self.tokenizer(doc)
            word_count = Counter(words)
            # Initialize a row for the document
            row = [0] * len(self.vocabulary_)
            # For each word and its count
            for word, count in word_count.items():
                # If the word is in the vocabulary, calculate its TF-IDF and add it to the row
                if word in self.vocabulary_:
                    tf = count / len(words)
                    idf = self.idf_[self.vocabulary_[word]]
                    row[self.vocabulary_[word]] = tf * idf

            matrix.append(row)
        return np.array(matrix)

    def fit_transform(self, corpus):
        """
             Fit the model to a corpus and transform the corpus into TF-IDF vectors.
        """
        self.fit(corpus)
        return self.transform(corpus)

class VectorSpaceModel:
    """
        Vector space model built on a given corpus.
    """
    def __init__(self, corpus: List[str]):
        """
            Initialize the VectorSpaceModel with a corpus of text.
        """
        self.corpus = corpus
        self.vectorizer = CustomTfidfVectorizer(tokenizer=TextPreprocessor(corpus).tokenize_and_stem)
        self.tfidf_matrix = self.load_or_compute_tfidf_matrix()

    def load_or_compute_tfidf_matrix(self):
        """
            Load the TF-IDF matrix, vocabulary, and IDF values from files if they exist, otherwise compute them.
        """
        # If the TF-IDF matrix, vocabulary, and IDF values exist in files, load them
        if TFIDF_MATRIX_FILE.exists() and VOCABULARY_FILE.exists() and IDF_FILE.exists():
            with TFIDF_MATRIX_FILE.open('r') as file:
                self.tfidf_matrix = np.array(json.load(file))
            with VOCABULARY_FILE.open('r') as file:
                self.vectorizer.vocabulary_ = json.load(file)
            with IDF_FILE.open('r') as file:
                self.vectorizer.idf_ = json.load(file)
        else:
            # Otherwise, compute the TF-IDF matrix, vocabulary, and IDF values and save them to files
            self.tfidf_matrix = self.vectorizer.fit_transform(self.corpus).tolist()
            with TFIDF_MATRIX_FILE.open('w') as file:
                json.dump(self.tfidf_matrix, file)
            with VOCABULARY_FILE.open('w') as file:
                json.dump(self.vectorizer.vocabulary_, file)
            with IDF_FILE.open('w') as file:
                json.dump(self.vectorizer.idf_, file)
        return self.tfidf_matrix

    def compute_cosine_similarity(self, query):
        """
            Compute the cosine similarity between a query and each document in the corpus.
        """
        # Transform the query into a vector
        query_vector = self.vectorizer.transform([query])[0]
        cosine_similarities = []
        # For each document vector in the TF-IDF matrix
        for doc_vector in self.tfidf_matrix:
            # Compute the dot product between the query vector and the document vector
            dot_product = np.dot(query_vector, doc_vector)
            # Compute the norms of the query vector and the document vector
            norm_query = np.linalg.norm(query_vector)
            norm_doc = np.linalg.norm(doc_vector)
            # Compute the cosine similarity and add it to the list
            similarity = dot_product / (norm_query * norm_doc) if norm_query != 0 and norm_doc != 0 else 0
            cosine_similarities.append(similarity)
        return np.array(cosine_similarities)

    def process_queries(self, queries):
        """
            Process a list of queries by computing the cosine similarity for each one.
        """
        results = {}
        # For each query
        for query in queries:
            # Compute the cosine similarity and add it to the results
            cosine_similarities = self.compute_cosine_similarity(query)
            results[query] = cosine_similarities
        return results

if __name__ == "__main__":
    app = QApplication(sys.argv)

    loader = ResearchPapersLoader(RESEARCH_PAPERS_DIR, FILE_COUNT)
    research_papers = loader.load_research_papers()

    corpus = list(research_papers.values())

    # Create a VectorSpaceModel instance from the corpus
    vector_space_model = VectorSpaceModel(corpus)

    # Determine the number of neighbors for the KNN classifier
    n_neighbors = int(np.sqrt(len(y)))
    # Create a KNN classifier and fit it to the TF-IDF matrix
    knn = KNeighborsClassifier(n_neighbors=n_neighbors)
    knn.fit(vector_space_model.tfidf_matrix, y)

    # Determine the number of clusters for the KMeans clustering
    n_clusters = int(np.sqrt(len(y)))
    # Create a KMeans instance and fit it to the TF-IDF matrix
    kmeans = KMeans(n_clusters=n_clusters)
    kmeans.fit(vector_space_model.tfidf_matrix)

    # Create a test corpus and labels from the sample test data
    sample_test_corpus = list(sample_test_data.values())
    sample_test_labels = list(sample_test_data.keys())

    # Transform the test corpus into vectors
    sample_test_vectors = vector_space_model.vectorizer.transform(sample_test_corpus)

    # Predict the labels for the test vectors
    sample_test_predictions = knn.predict(sample_test_vectors)

    # Compute the precision, recall, F1 score, and accuracy of the predictions
    precision = precision_score(sample_test_labels, sample_test_predictions, average='macro', zero_division=0)
    recall = recall_score(sample_test_labels, sample_test_predictions, average='macro')
    f1 = f1_score(sample_test_labels, sample_test_predictions, average='macro')
    accuracy = accuracy_score(sample_test_labels, sample_test_predictions)

    gui = GUI(vector_space_model, research_papers)
    gui.run()