import os
import re
import string
import json
import numpy as np
from collections import defaultdict, Counter
from nltk.stem import PorterStemmer
import tkinter as tk
from tkinter import ttk, scrolledtext

# import nltk
# from nltk.corpus import stopwords

# # nltk.download('stopwords')
# STOPWORDS = set(stopwords.words('english'))

# Function to load stopwords
def load_file(file_path):
    with open(file_path, 'r', encoding='latin-1') as file:
        return [word.strip() for word in file.readlines()]

STOPWORDS = load_file("Stopword-List.txt")

# Function to preprocess query
def preprocess_query(text: str) -> list:
    """Preprocess the query by tokenizing, removing punctuation and stopwords, and stemming."""
    text = text.translate(str.maketrans('', '', string.punctuation + string.digits)).lower()
    tokens = re.findall(r"\w+(?:['-,]\w+)?|[^_\w\s]", text)
    stemmer = PorterStemmer()
    return [stemmer.stem(token) for token in tokens if token.isalpha() and token not in STOPWORDS]

# Function to load or compute data
def load_inverted_index_from_json(corpus: list, tokenizer) -> dict:
    total_documents = len(corpus)
    document_count = defaultdict(int)
    vocabulary = {}
    idf = []
    for doc in corpus:
        words = set(tokenizer(doc))
        for word in words:
            document_count[word] += 1
    for word, count in document_count.items():
        vocabulary[word] = len(vocabulary)
        idf_value = 1 + np.log(total_documents / (1 + count))
        idf.append(idf_value)
    tfidf_matrix = []
    for doc in corpus:
        words = tokenizer(doc)
        word_count = Counter(words)
        row = [0] * len(vocabulary)
        for word, count in word_count.items():
            if word in vocabulary:
                tf = count / len(words)
                idf_value = idf[vocabulary[word]]
                row[vocabulary[word]] = tf * idf_value
        tfidf_matrix.append(row)

    # Save data to separate files
    with open('tfidf_matrix.json', 'w') as tfidf_file:
        json.dump(tfidf_matrix, tfidf_file)
    with open('vocabulary.json', 'w') as vocab_file:
        json.dump(vocabulary, vocab_file)
    with open('idf.json', 'w') as idf_file:
        json.dump(idf, idf_file)
    return np.array(tfidf_matrix), vocabulary, idf

# Function to compute cosine similarity
def compute_cosine_similarity(query: str, tfidf_matrix: np.array, tokenizer, vocabulary, idf) -> np.array:
    """Compute cosine similarity between query and documents."""
    query_vector = np.zeros(len(vocabulary))
    words = tokenizer(query)
    word_count = Counter(words)
    for word, count in word_count.items():
        if word in vocabulary:
            tf = count / len(words)
            idf_value = idf[vocabulary[word]]
            query_vector[vocabulary[word]] = tf * idf_value
    cosine_similarities = []
    for doc_vector in tfidf_matrix:
        dot_product = np.dot(query_vector, doc_vector)
        norm_query = np.linalg.norm(query_vector)
        norm_doc = np.linalg.norm(doc_vector)
        similarity = dot_product / (norm_query * norm_doc) if norm_query != 0 and norm_doc != 0 else 0
        cosine_similarities.append(similarity)
    return np.array(cosine_similarities)

# Function to rank documents
def rank_documents(queries: list, tfidf_matrix: np.array, tokenizer, vocabulary, idf) -> dict:
    """Rank documents based on cosine similarity."""
    results = {}
    for query in queries:
        cosine_similarities = compute_cosine_similarity(query, tfidf_matrix, tokenizer, vocabulary, idf)
        results[query] = cosine_similarities.tolist()
    return results

# Function to perform search and display results
def perform_search():
    """Perform search and display results."""
    query = query_entry.get()
    if query:
        results = rank_documents([query], tfidf_matrix, preprocess_query, vocabulary, idf)
        relevant_docs = [(list(research_papers.keys())[idx], sim) for idx, sim in enumerate(results[query]) if sim >= 0.05]
        relevant_docs.sort(key=lambda x: x[1], reverse=True)
        if relevant_docs:
            for doc, score in relevant_docs:
                results_text.insert(tk.END, f"Document: {doc} - Cosine Similarity Score: {score:.3f}\n")
        else:
            results_text.insert(tk.END, "No relevant documents found.\n")
        with open("results.json", 'w') as file:
            json.dump(results, file)

# Function to refresh window
def refresh_window():
    """Refresh the window for another input."""
    query_entry.delete(0, tk.END)
    results_text.delete('1.0', tk.END)

research_papers = {}
pathofpapers = 'ResearchPapers'
for i in range(1, 31):
    path = f'{pathofpapers}/{i}.txt'
    if os.path.exists(path):
        with open(path, 'r', encoding='latin-1') as file:
            content = file.read()
            research_papers[os.path.basename(path)] = content
corpus = list(research_papers.values())

tfidf_matrix, vocabulary, idf = load_inverted_index_from_json(corpus, preprocess_query)

# Create the main window
root = tk.Tk()
root.title("VSM RANK SEARCH")
root.configure(bg='#5c6bc0')

# Create a frame for the query entry and search button
query_frame = ttk.Frame(root, padding="20", style='Query.TFrame')
query_frame.pack()

# Create a label for the query
query_label = ttk.Label(query_frame, text="Enter Query:", style='Query.TLabel')
query_label.grid(row=0, column=0, sticky="w")

# Create a text box for the query
query_entry = ttk.Entry(query_frame, width=50)
query_entry.grid(row=0, column=1, padx=5, pady=5)

# Create a button to start the search
search_button = ttk.Button(query_frame, text="Search", command=perform_search, style='Search.TButton')
search_button.grid(row=0, column=2, padx=5, pady=5)

# Create a button to refresh the window for another input
refresh_button = ttk.Button(root, text="Clear", command=refresh_window, style='Refresh.TButton')
refresh_button.pack(pady=5)

# Create a text box to display the results
results_text = scrolledtext.ScrolledText(root, width=70, height=20, bg='#ffffff')
results_text.pack(padx=20, pady=10)

# Create a label for the footer
footer_label = ttk.Label(root, text="\t\t\t\t\t K214503 Muhammad Tahir", style='Footer.TLabel')
footer_label.pack(side="bottom", fill="x")

style = ttk.Style()
style.configure('Query.TFrame', background='#5c6bc0')  # Frame background color
style.configure('Query.TLabel', background='#5c6bc0', foreground='#000000')  # Label background and text color
style.configure('Search.TButton', background='#4caf50', foreground='#000000')  # Button color
style.configure('Refresh.TButton', background='#2196f3', foreground='#000000')  # Button color
style.configure('Footer.TLabel', background='#5c6bc0', foreground='#000000')  # Footer background and text color

# Start the main loop
root.mainloop()