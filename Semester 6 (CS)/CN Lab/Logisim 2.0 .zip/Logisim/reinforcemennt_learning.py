import numpy as np

state_size = 10  
action_size = 4 

q_table = np.zeros((state_size, action_size))
alpha = 0.8
gamma = 0.95

num_episodes = 1000

def get_next_state_and_reward(state, action):
    next_state = (state + action) % state_size
    reward = 1 if next_state == 0 else 0
    return next_state, reward

for episode in range(num_episodes):
    state = 0 
    done = False
    while not done:
        action = np.argmax(q_table[state, :] + np.random.randn(1, action_size) * (1. / (episode + 1)))
        next_state, reward = get_next_state_and_reward(state, action)
        q_table[state, action] = (1 - alpha) * q_table[state, action] + \
                                 alpha * (reward + gamma * np.max(q_table[next_state, :]))
        state = next_state
        # Define your own condition to end the episode
        done = state == 0 

print(q_table)
